import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors={
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type"
};

Deno.serve(async(req)=>{
  if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
  try{
    const auth=req.headers.get("Authorization");
    if(!auth)throw new Error("Authentication required.");

    const admin=createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const userClient=createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      {global:{headers:{Authorization:auth}}}
    );

    const {data:{user}}=await userClient.auth.getUser();
    if(!user)throw new Error("Invalid session.");

    const {video_id,frames=[]}=await req.json();
    const {data:video,error:vErr}=await userClient.from("videos").select("*").eq("id",video_id).single();
    if(vErr||!video)throw new Error("Video not found.");

    const {data:notes}=await userClient.from("annotations").select("*").eq("video_id",video_id).order("timestamp_seconds");
    const evidence=(notes||[]).map((n:any)=>
      `${Number(n.timestamp_seconds).toFixed(1)}s | ${n.type} | ${n.payload?.text||"visual mark"}`
    ).join("\n");

    const parts:any[]=[{
      text:`You are an evidence-first competitive Free Fire MAX gameplay coach.
Analyze ONLY what is visible in the supplied screenshots and the saved player evidence.
Do not invent kills, deaths, weapons, enemies, map positions, sensitivity values, or events that are not visible.
Screenshots are sampled moments, not the entire match, so never claim continuous behavior from them.

Video title: ${video.title}

Saved player evidence:
${evidence||"No manual evidence was saved."}

Return:
1. Match snapshot: only directly visible facts
2. Likely mistakes: separate observed facts from coaching inference
3. Aim/crosshair
4. Movement/positioning
5. Decision-making
6. 3 specific drills
7. What to record next match
8. Confidence: High/Medium/Low, with reasons
9. Limitations: explicitly state that sampled frames cannot prove events between frames.

Be practical and concise. If evidence is insufficient, say so instead of guessing.`
    }];

    for(const f of (Array.isArray(frames)?frames.slice(0,8):[])){
      if(f?.image)parts.push({text:`Gameplay frame around ${Number(f.time||0).toFixed(1)} seconds:`});
      if(f?.image)parts.push({inline_data:{mime_type:"image/jpeg",data:f.image}});
    }

    const key=Deno.env.get("GEMINI_API_KEY");
    if(!key)throw new Error("GEMINI_API_KEY is not configured.");

    const r=await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="+encodeURIComponent(key),
      {method:"POST",headers:{"Content-Type":"application/json"},
       body:JSON.stringify({contents:[{parts}],generationConfig:{temperature:0.2}})}
    );
    const j=await r.json();
    if(!r.ok)throw new Error(j?.error?.message||"AI request failed.");

    const report=j?.candidates?.[0]?.content?.parts?.map((p:any)=>p.text||"").join("")||"";
    if(!report)throw new Error("AI returned no report.");

    const {error:saveErr}=await admin.from("ai_reports").insert({video_id,user_id:user.id,report});
    if(saveErr)throw saveErr;

    return new Response(JSON.stringify({report}),{headers:{...cors,"Content-Type":"application/json"}});
  }catch(e){
    return new Response(JSON.stringify({error:String(e?.message||e)}),{
      status:400,headers:{...cors,"Content-Type":"application/json"}
    });
  }
});