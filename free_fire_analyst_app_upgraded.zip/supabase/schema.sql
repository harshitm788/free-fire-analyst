create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  storage_path text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.annotations (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  timestamp_seconds numeric not null,
  type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.ai_reports (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references public.videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  report text not null,
  created_at timestamptz not null default now()
);

alter table public.videos enable row level security;
alter table public.annotations enable row level security;
alter table public.ai_reports enable row level security;

drop policy if exists "users own videos" on public.videos;
create policy "users own videos" on public.videos for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

drop policy if exists "users own annotations" on public.annotations;
create policy "users own annotations" on public.annotations for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

drop policy if exists "users own reports" on public.ai_reports;
create policy "users own reports" on public.ai_reports for all using (auth.uid()=user_id) with check (auth.uid()=user_id);

insert into storage.buckets (id,name,public) values ('gameplay-videos','gameplay-videos',false)
on conflict (id) do nothing;

drop policy if exists "upload own gameplay" on storage.objects;
create policy "upload own gameplay" on storage.objects for insert to authenticated
with check (bucket_id='gameplay-videos' and (storage.foldername(name))[1]=auth.uid()::text);

drop policy if exists "read own gameplay" on storage.objects;
create policy "read own gameplay" on storage.objects for select to authenticated
using (bucket_id='gameplay-videos' and (storage.foldername(name))[1]=auth.uid()::text);

drop policy if exists "delete own gameplay" on storage.objects;
create policy "delete own gameplay" on storage.objects for delete to authenticated
using (bucket_id='gameplay-videos' and (storage.foldername(name))[1]=auth.uid()::text);
